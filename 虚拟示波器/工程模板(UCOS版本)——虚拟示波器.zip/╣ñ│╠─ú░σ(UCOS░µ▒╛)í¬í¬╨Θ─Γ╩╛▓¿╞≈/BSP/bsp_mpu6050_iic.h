#ifndef __BSP_MPU6050_IIC_H
#define __BSP_MPU6050_IIC_H

#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"






#define BSP_I2C_SCL_PIN                  GPIO_Pin_9                 
#define BSP_I2C_SCL_GPIO_PORT            GPIOB                       
#define BSP_I2C_SCL_GPIO_CLK             RCC_AHB1Periph_GPIOB

#define BSP_I2C_SDA_PIN                  GPIO_Pin_8                 
#define BSP_I2C_SDA_GPIO_PORT            GPIOB                     
#define BSP_I2C_SDA_GPIO_CLK             RCC_AHB1Periph_GPIOB



#define BSP_IIC_SCL_1()  GPIO_SetBits  (BSP_I2C_SCL_GPIO_PORT, BSP_I2C_SCL_PIN)		/* SCL = 1 */
#define BSP_IIC_SCL_0()  GPIO_ResetBits(BSP_I2C_SCL_GPIO_PORT, BSP_I2C_SCL_PIN)		/* SCL = 0 */

#define BSP_IIC_SDA_1()  GPIO_SetBits  (BSP_I2C_SDA_GPIO_PORT, BSP_I2C_SDA_PIN)		/* SDA = 1 */
#define BSP_IIC_SDA_0()  GPIO_ResetBits(BSP_I2C_SDA_GPIO_PORT, BSP_I2C_SDA_PIN)		/* SDA = 0 */

#define BSP_IIC_SDA_READ()  GPIO_ReadInputDataBit(BSP_I2C_SDA_GPIO_PORT, BSP_I2C_SDA_PIN)	/* ��SDA����״̬ */





void bsp_iic_init(void);
unsigned char bsp_iic_write_buff(unsigned char addr,unsigned char reg,unsigned char *value,unsigned char len);
unsigned char bsp_iic_read_buff(unsigned char addr,unsigned char reg,unsigned char *buff,unsigned char len);
unsigned char bsp_iic_write_reg(unsigned char addr,unsigned char reg,unsigned char value);
unsigned char bsp_iic_read_reg(unsigned char addr,unsigned char reg);
#endif
