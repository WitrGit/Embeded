#ifndef __BSP_KEY_H
#define __BSP_KEY_H

#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#define KEY_PIN                  GPIO_Pin_0                 
#define KEY_GPIO_PORT            GPIOA                      
#define KEY_GPIO_CLK             RCC_AHB1Periph_GPIOA

#define bsp_key_get_key() GPIO_ReadInputDataBit(KEY_GPIO_PORT,KEY_PIN)
void bsp_key_init(void);
unsigned char bsp_key_scan(void);



#endif
