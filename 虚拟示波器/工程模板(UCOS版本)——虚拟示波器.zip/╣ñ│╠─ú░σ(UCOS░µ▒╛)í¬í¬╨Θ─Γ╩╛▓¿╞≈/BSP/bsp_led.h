#ifndef __BSP_LED_H
#define __BSP_LED_H

#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#define LED1_PIN                  GPIO_Pin_3                 
#define LED1_GPIO_PORT            GPIOC                      
#define LED1_GPIO_CLK             RCC_AHB1Periph_GPIOC

#define LED2_PIN                  GPIO_Pin_6                 
#define LED2_GPIO_PORT            GPIOF                      
#define LED2_GPIO_CLK             RCC_AHB1Periph_GPIOF


#define LED3_PIN                  GPIO_Pin_7                 
#define LED3_GPIO_PORT            GPIOF                      
#define LED3_GPIO_CLK             RCC_AHB1Periph_GPIOF


#define set_led_state(a)	if (a)	\
					GPIO_SetBits(LED1_GPIO_PORT,LED1_PIN);\
					else		\
					GPIO_ResetBits(LED1_GPIO_PORT,LED1_PIN)
					

void bsp_led_init(void);
void bsp_led_chg(void);
#endif
