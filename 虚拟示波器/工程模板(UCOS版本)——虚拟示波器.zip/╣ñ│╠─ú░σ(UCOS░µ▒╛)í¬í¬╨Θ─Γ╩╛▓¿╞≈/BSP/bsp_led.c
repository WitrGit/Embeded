#include "bsp_led.h"



void bsp_led_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd ( LED1_GPIO_CLK, ENABLE); 
	RCC_AHB1PeriphClockCmd ( LED2_GPIO_CLK, ENABLE); 
	RCC_AHB1PeriphClockCmd ( LED3_GPIO_CLK, ENABLE); 
	
	GPIO_InitStructure.GPIO_Pin = LED1_PIN;	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT; 
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; 
	GPIO_Init(LED1_GPIO_PORT, &GPIO_InitStructure);	

	
	GPIO_InitStructure.GPIO_Pin = LED2_PIN;	
	GPIO_Init(LED2_GPIO_PORT, &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = LED3_PIN;	
	GPIO_Init(LED3_GPIO_PORT, &GPIO_InitStructure);	
}


void bsp_led_state(unsigned char n,unsigned char state)
{
	switch(n)
	{
		case 0:GPIO_WriteBit(LED1_GPIO_PORT,LED1_PIN,(BitAction)state);break;
		case 1:GPIO_WriteBit(LED2_GPIO_PORT,LED2_PIN,(BitAction)state);break;
		case 2:GPIO_WriteBit(LED3_GPIO_PORT,LED3_PIN,(BitAction)state);break;
	}
}

unsigned char get_led_state(unsigned char n)
{
	unsigned char state = 0;
	switch(n)
	{
		case 0:state = GPIO_ReadOutputDataBit(LED1_GPIO_PORT,LED1_PIN);break;
		case 1:state = GPIO_ReadOutputDataBit(LED2_GPIO_PORT,LED2_PIN);break;
		case 2:state = GPIO_ReadOutputDataBit(LED3_GPIO_PORT,LED3_PIN);break;
	}
	return state ;
}

void bsp_led_chg(void)
{
	bsp_led_state(1,(1 - get_led_state(1)));
}


