#include "bsp_mpu6050_iic.h"


void bsp_iic_init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;  
  
  /*ʹ�ܴ�����ʹ�õ����ŵ�ʱ��*/
  RCC_AHB1PeriphClockCmd(BSP_I2C_SCL_GPIO_CLK|BSP_I2C_SDA_GPIO_CLK,ENABLE);

    
    /*����SCL���� */   
    GPIO_InitStructure.GPIO_Pin = BSP_I2C_SCL_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_Init(BSP_I2C_SCL_GPIO_PORT, &GPIO_InitStructure);

    /*����SDA���� */
    GPIO_InitStructure.GPIO_Pin = BSP_I2C_SDA_PIN;
    GPIO_Init(BSP_I2C_SDA_GPIO_PORT, &GPIO_InitStructure);

}

void BSP_IIC_SDA_STATE(unsigned  char s)
{
	GPIO_InitTypeDef GPIO_InitStructure;  
	
	GPIO_InitStructure.GPIO_Pin = BSP_I2C_SDA_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	if(s == 0)
	{
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
		GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_DOWN;	
	}
	else
	{
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	}

	GPIO_Init(BSP_I2C_SDA_GPIO_PORT, &GPIO_InitStructure);
}


static void bsp_iic_delay(void)
{
	uint8_t i;
	for (i = 0; i < 10*2; i++);
}

void bsp_iic_start(void)
{
	BSP_IIC_SDA_STATE(1);
	BSP_IIC_SDA_1();
	BSP_IIC_SCL_1();
	bsp_iic_delay();
	BSP_IIC_SDA_0();
	bsp_iic_delay();
	BSP_IIC_SCL_0();
}
void bsp_iic_stop(void)
{
  BSP_IIC_SDA_STATE(1);
	BSP_IIC_SDA_0();
	BSP_IIC_SCL_1();
	bsp_iic_delay();
	BSP_IIC_SDA_1();
	bsp_iic_delay();
}

unsigned char bsp_iic_wait_ack(void)
{
	unsigned char re;

	BSP_IIC_SCL_1();	
	bsp_iic_delay();
	BSP_IIC_SDA_STATE(0);
	if (BSP_IIC_SDA_READ())	
	{
		re = 1;
	}
	else
	{
		re = 0;
	}
	BSP_IIC_SDA_STATE(1);
	BSP_IIC_SCL_0();
	bsp_iic_delay();
	return re;
}


void bsp_iic_ack(void)
{
	BSP_IIC_SDA_0();	/* CPU����SDA = 0 */
	bsp_iic_delay();
	BSP_IIC_SCL_1();	/* CPU����1��ʱ�� */
	bsp_iic_delay();
	BSP_IIC_SCL_0();
	bsp_iic_delay();
	BSP_IIC_SDA_1();	/* CPU�ͷ�SDA���� */
}


void bsp_iic_nack(void)
{
	BSP_IIC_SDA_1();	/* CPU����SDA = 1 */
	bsp_iic_delay();
	BSP_IIC_SCL_1();	/* CPU����1��ʱ�� */
	bsp_iic_delay();
	BSP_IIC_SCL_0();
	bsp_iic_delay();	
}


void bsp_iic_send_byte(unsigned char data)
{
	unsigned char i;
  BSP_IIC_SDA_STATE(1);
	BSP_IIC_SCL_0();
	for (i = 0; i < 8; i++)
	{		
		if (data & 0x80)
		{
			BSP_IIC_SDA_1();
		}
		else
		{
			BSP_IIC_SDA_0();
		}
		bsp_iic_delay();
		BSP_IIC_SCL_1();
		bsp_iic_delay();	
		BSP_IIC_SCL_0();
		data <<= 1;	/* ����һ��bit */
		bsp_iic_delay();
	}
	
	bsp_iic_wait_ack();
}

unsigned char bsp_iic_read_byte(void)
{
	unsigned char i;
	unsigned char value;

	/* ������1��bitΪ���ݵ�bit7 */
	value = 0;
	
	BSP_IIC_SDA_1();
	BSP_IIC_SDA_STATE(0);
	
	for (i = 0; i < 8; i++)
	{
		value <<= 1;
		BSP_IIC_SCL_0();
		bsp_iic_delay();
		BSP_IIC_SCL_1();
		if (BSP_IIC_SDA_READ())
		{
			value++;
		}
		
		bsp_iic_delay();
	}
	
	return value;
}

unsigned char bsp_iic_write_reg(unsigned char addr,unsigned char reg,unsigned char value)
{
	bsp_iic_start();
	bsp_iic_send_byte(addr);
	bsp_iic_send_byte(reg);
	bsp_iic_send_byte(value);  
	bsp_iic_stop(); 
	bsp_iic_delay();
	return 1;
}

unsigned char bsp_iic_read_reg(unsigned char addr,unsigned char reg)
{
    unsigned char res;
	  bsp_iic_start();
    bsp_iic_send_byte(addr ); 
		bsp_iic_send_byte(reg);
		
	
	  bsp_iic_start();
		 
    bsp_iic_send_byte(addr+1);  
	  res = bsp_iic_read_byte(); 
		
		 
		bsp_iic_nack();
		bsp_iic_stop(); 	
		return res;  		
}

unsigned char bsp_iic_write_buff(unsigned char addr,unsigned char reg,unsigned char *value,unsigned char len)
{
	bsp_iic_start();
	bsp_iic_send_byte(addr );
	bsp_iic_send_byte(reg);
	bsp_iic_wait_ack();
	while(len--)  
	{  
			bsp_iic_send_byte(* value);  
			bsp_iic_wait_ack();  
			value++;  
	}  
	bsp_iic_stop();  
	return 1;
}
unsigned char bsp_iic_read_buff(unsigned char addr,unsigned char reg,unsigned char *buff,unsigned char len)
{
    unsigned char res;
	  bsp_iic_start();
    bsp_iic_send_byte(addr );
		if(!bsp_iic_wait_ack())  
		{  
				bsp_iic_stop();   
				return 0;  
		}  
		bsp_iic_send_byte(reg);
		
		bsp_iic_wait_ack();  
    bsp_iic_start();  
    bsp_iic_send_byte(((reg & 0x0700) >>7) | addr | 0x0001);  
    bsp_iic_wait_ack();
	  while(len)  
    {  
        *buff = bsp_iic_read_byte();  
        if(len == 1)
					bsp_iic_nack();  
        else 
					bsp_iic_ack();   
        buff++;  
        len--;  
    }  
		bsp_iic_stop(); 	
		return 1;  		
}


