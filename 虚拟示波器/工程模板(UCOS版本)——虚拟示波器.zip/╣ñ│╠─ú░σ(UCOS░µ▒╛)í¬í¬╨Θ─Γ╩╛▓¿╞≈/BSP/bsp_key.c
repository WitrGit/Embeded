#include "bsp_key.h"


void bsp_key_init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	

	RCC_AHB1PeriphClockCmd(KEY_GPIO_CLK,ENABLE);
	

	GPIO_InitStructure.GPIO_Pin = KEY_PIN; 
  

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN; 
  

  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	

	GPIO_Init(KEY_GPIO_PORT, &GPIO_InitStructure);   
  	
}

unsigned char bsp_key_scan(void)
{
	if(bsp_key_get_key() == 1)
	{
		while(bsp_key_get_key());
		return 1;
	}
	return 0;
}





