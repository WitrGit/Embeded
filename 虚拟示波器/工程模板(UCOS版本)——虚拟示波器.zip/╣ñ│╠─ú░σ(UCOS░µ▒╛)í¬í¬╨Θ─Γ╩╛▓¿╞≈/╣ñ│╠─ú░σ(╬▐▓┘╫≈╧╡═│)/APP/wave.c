#include "wave.h"
#include "math.h"
#include "bsp_ili9806g_lcd.h"

#define DRAW_SIZE 800
#define DATA_SIZE 400

#define AXIS_OFFSET 55

#define ABS(x)  ( (x)>0?(x):-(x) )


unsigned short show_num_size = 400;
unsigned short show_offset = 10;
unsigned short show_offset_max = 0;

float draw_wave_table [DRAW_SIZE];
float get_data_table  [DATA_SIZE];


#define PI  3.1415926


void Interpolation_Calculation(float a,float b,float *tmp,unsigned short len)
{
	  float t = 0;
    unsigned short i = 0;
    for ( i = 1; i < len; i++)
    {
        t = i*1.0 / len;
        t = (t) * (t) * (3 - 2 * (t));
        tmp[i-1] = (b * t) + (a * (1 - t));
        tmp[i] = b;
    }	
}

void get_all_data(void)
{
	unsigned short i = 0;
	for(i=0;i<DATA_SIZE;i++)
	{
		get_data_table[i] =Wave_Get_Data();//(500*sin(10*i*3.1415/180));//
	}
}



float get_wave_data(void)
{
	float next_data = 0;
	float end_data = 0;
	float max_data = 0;
	unsigned short i = 0;
	unsigned short tmp = DRAW_SIZE/show_num_size;
	for(i=0;i<DRAW_SIZE;i++)
	{
		draw_wave_table[i] = 0;
	}
	max_data = ABS(draw_wave_table[0]);
	for(i=0;i<show_num_size;i++)
	{
		max_data = (max_data<ABS(get_data_table[i+show_offset]))?ABS(get_data_table[i+show_offset]):max_data;
		show_offset_max = DATA_SIZE - show_num_size;
		show_offset = (show_offset>show_offset_max)?0:show_offset;
		draw_wave_table[tmp * i] = get_data_table[i+show_offset];
	}

	end_data = (i<DATA_SIZE)?get_data_table[i]:0;
	
	for(i=0;i<show_num_size;i++)
	{
		
		next_data = (tmp * (i + 1) < DRAW_SIZE)?draw_wave_table[tmp * (i + 1)]:end_data;
		Interpolation_Calculation(draw_wave_table[tmp * i], next_data, &draw_wave_table[tmp * i], (tmp + 1));
	}
	

	return max_data;
	
}

void itoc(unsigned int value)
{
	 char show_data[7] = {0};
	unsigned int value_temp = value;
	unsigned char i = 0;
	if(value<99999)
	{
		for(i=0; i<5; i++)
		{
			show_data[5-i] = value_temp%10 +'0';
			value_temp = (value_temp - value_temp%10)/10;
		}
		show_data[6] = '\0';
		show_data[0] = '+';		
		ILI9806G_DispString_EN(0,0,(char *)show_data);
		
		show_data[0] = '-';		
		ILI9806G_DispString_EN(0,194,(char *)show_data);
		
		value_temp = value/2;
		if(value_temp == 0)
		{
			ILI9806G_DispString_EN(0,46,"      ");
			ILI9806G_DispString_EN(0,146,"      ");
			return ;
		}
		for(i=0; i<5; i++)
		{
			show_data[5-i] = value_temp%10 +'0';
			value_temp = (value_temp - value_temp%10)/10;
		}
		show_data[6] = '\0';
		show_data[0] = '+';		
		ILI9806G_DispString_EN(0,46,(char *)show_data);
		
		show_data[0] = '-';		
		ILI9806G_DispString_EN(0,146,(char *)show_data);
	}
	
	
	
	
}

void LCD_Draw_Axis(unsigned int max)
{
	unsigned char i = 0;
	LCD_SetTextColor(WHITE);
	ILI9806G_DrawLine(AXIS_OFFSET-1,99,800+AXIS_OFFSET-1,99);
	ILI9806G_DrawLine(AXIS_OFFSET-1,200,800+AXIS_OFFSET-1,200);
	ILI9806G_DrawLine(AXIS_OFFSET-1,0,AXIS_OFFSET-1,200);
	
	itoc(max);
	
	for(i=0; i<5; i++)
	{
		ILI9806G_DrawLine(AXIS_OFFSET-5,i*50,AXIS_OFFSET-1,i*50);

	}

}

void wave_clear(void)
{
	unsigned short i = 0;
	unsigned short j = 0;
	unsigned short Pixel = 0;
	for(i=0;i<800;i++)
	{
		for(j=0;j<200;j++)
		{
			Pixel = ILI9806G_GetPointPixel(i+AXIS_OFFSET,j);
			Pixel = (Pixel == GREEN)?BLACK:BLACK;
			LCD_SetTextColor(Pixel);
			ILI9806G_SetPointPixel(i+AXIS_OFFSET,j);
			break;
		}
	}
}

void LCD_Draw_Wave(void)
{
	 short i = 0;
	 short j = 0;
	 short st = AXIS_OFFSET;
	 short en = 0;
	unsigned int max = 0;
	get_all_data();
	max = (unsigned int)get_wave_data()+1;
	
	LCD_Draw_Axis(max);
	
	//������Ļ����������
  LCD_SetTextColor(GREEN);
	ILI9806G_Clear(AXIS_OFFSET,0,854-AXIS_OFFSET,99);
	ILI9806G_Clear(AXIS_OFFSET,101,854-AXIS_OFFSET,99);
	
	

	en = 100-draw_wave_table[0]/max*100;

	for(i=0;i<DRAW_SIZE-6;i++)
	{
		j =100-draw_wave_table[i]/max*100;
		
		ILI9806G_ClearVertical(i,1);
		
		ILI9806G_DrawLine(st,en,i+AXIS_OFFSET,j);
	
		st = i+AXIS_OFFSET;
		en = j;
	}
	
}





