#ifndef __WAVE_H
#define __WAVE_H


void LCD_Draw_Wave(void);

float Wave_Get_Data(void);

#endif
