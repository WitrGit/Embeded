#include "bsp_ili9806g_lcd.h"
#include "debug.h"

#define OffSet_X 0
#define OffSet_Y 260
#define DEBUG_LEN 10


unsigned char cmd_table[DEBUG_LEN][30] = {""};
void show_cmd_table(void)
{
	unsigned char i = 0;
	LCD_SetColors(BLUE,0x0000);
	for(i=0;i<DEBUG_LEN;i++)
	{
    
		ILI9806G_DispString_EN(OffSet_X,OffSet_Y+i*20,(char *)cmd_table[i]);
	}
}

void set_cmd( char *p_arg,int value,unsigned char size,unsigned char v_show)
{
	unsigned char i = 0;
	unsigned char j = 0;
	int value_temp ;
	for(i=1; i<DEBUG_LEN; i++)
	{
		for(j=0; cmd_table[i][j]!='\0';j++)
		{
			cmd_table[i-1][j] = cmd_table[i][j];
		}
		cmd_table[i-1][j] = '\0';
	}
	i=0;
  while(p_arg[i]!='\0')
	{
	  cmd_table[DEBUG_LEN-1][i] = p_arg[i];
		i++;
	}
	if(v_show == 1)
	{
	 cmd_table[DEBUG_LEN-1][i++] = ':';
	 cmd_table[DEBUG_LEN-1][i++] = ' ';
	 if(value<0)
	 {	 
		 cmd_table[DEBUG_LEN-1][i] = '-';
		 value_temp = -value;
	 }
	 else
	 {
		 cmd_table[DEBUG_LEN-1][i] = '+';
		 value_temp = value;		 
	 }
	 
	   for(j=0; j<size; j++)
		{
			cmd_table[DEBUG_LEN-1][i+size-j] = value_temp%10 +'0';
			value_temp = (value_temp - value_temp%10)/10;
		}	
	 
	
		for(j=i+size+1; j<29;j++)
		{
			cmd_table[DEBUG_LEN-1][j] = ' ';
		}	
	}
	else
	{
		for(j=i; j<29;j++)
		{
			cmd_table[DEBUG_LEN-1][j] = ' ';
		}			
		
	}

			cmd_table[DEBUG_LEN-1][j] = '\0';
}


