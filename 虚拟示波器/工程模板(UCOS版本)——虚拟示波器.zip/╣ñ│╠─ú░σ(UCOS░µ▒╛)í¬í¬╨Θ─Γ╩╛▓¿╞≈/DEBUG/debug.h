#ifndef __DEBUG_H
#define __DEBUG_H


void show_cmd_table(void);
void set_cmd( char *p_arg,int value,unsigned char size,unsigned char v_show);
#endif

