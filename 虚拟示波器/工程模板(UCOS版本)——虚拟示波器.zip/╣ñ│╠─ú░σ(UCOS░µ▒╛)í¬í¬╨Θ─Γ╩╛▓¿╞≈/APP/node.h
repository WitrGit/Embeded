#ifndef __NODE_H
#define __NODE_H

void NODE_Init(void);
void Get_One_Data(float data);
void Exchange_Data(float *p_arg);
#endif

