#ifndef __FILTER_H
#define __FILTER_H


float KalmanFilter(float ResrcData);
#endif
