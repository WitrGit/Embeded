#include "includes.h"
#include "bsp_led.h"
#include "bsp_adc.h"
#include "bsp_usart.h"
#include "bsp_ili9806g_lcd.h"
#include "debug.h"
#include "bsp_key.h"
#include "wave.h"
#include "math.h"
#include "gt5xx.h"
#include "bsp_mpu6050.h"
#include "control.h"
#include "3d.h"
void delay_main1(unsigned int tm)
{
	while(tm--);
}




//int main(void)
//{

//	ILI9806G_Init();

//  t3d_init();
//	while(1)
//	{
//		t3d_set_angle(0,0,0);
//		t3d_play();
//		delay_main1(0xEFffff);
//	}
//	return 0;
//}



// 
//float ADC_ConvertedValueLocal; 

///*****************************��������********************************/
//static  void  app_start     (void *p_arg);

//static  void  app_creat_task(void);

//static void app_lcd_show(void *p_arg);

//static void app_data_get(void *p_arg);

//static void app_gt5x_get(void *p_arg);

//static void app_task_mag(void *p_arg);

//static void app_tmr1_cb(OS_TMR *tmr,void *p_arg);

//static void app_tmr_mag(void *p_arg);
///*****************************�������********************************/
////������������
//#define app_start_prio     3u
//#define app_start_stk_size 128u
//static  OS_TCB  app_start_tcb;
//static  CPU_STK app_start_stk[app_start_stk_size];

////���ݲɼ�

//#define app_data_get_prio     4u
//#define app_data_get_stk_size 128u//����ʹ��30


//static OS_TCB  app_data_get_tcb;
//static CPU_STK app_data_get_stk[app_data_get_stk_size];


////��ʾ����ʾ����

//#define app_lcd_show_prio     5u
//#define app_lcd_show_stk_size 75u //����ʹ��50


//static OS_TCB  app_lcd_show_tcb;
//static CPU_STK app_lcd_show_stk[app_lcd_show_stk_size];



////���������ʾ����

//#define app_task_mag_prio     7u
//#define app_task_mag_stk_size 128u


//static OS_TCB  app_task_mag_tcb;
//static CPU_STK app_task_mag_stk[app_task_mag_stk_size];


//#define app_gt5x_prio     6u
//#define app_gt5x_stk_size 128u//����ʹ��26


//static OS_TCB  app_gt5x_tcb;
//static CPU_STK app_gt5x_stk[app_gt5x_stk_size];



//#define app_tmr_prio     6u
//#define app_tmr_stk_size 128u//����ʹ��


//static OS_TCB  app_tmr_tcb;
//static CPU_STK app_tmr_stk[app_tmr_stk_size];

///*****************************�ź���********************************/

//static OS_SEM wave_sem;
//static OS_SEM wave1_sem;

///*****************************��ʱ��********************************/
//static OS_TMR os_tmr1;

//OS_TCB tcb_table[10];



//void get_all_tcb(void)
//{
//	tcb_table[0] = app_data_get_tcb;
//	tcb_table[1] = app_lcd_show_tcb;
//	tcb_table[2] = app_task_mag_tcb;
//	tcb_table[3] = app_gt5x_tcb;
//	tcb_table[4] = app_tmr_tcb;

//}


//void os_chk_stk(OS_TCB *tcb)
//{
//	OS_ERR err;
//	CPU_STK_SIZE FREE;
//	CPU_STK_SIZE USER;
//	OSTaskStkChk(tcb,&FREE,&USER,&err);
//	set_cmd(tcb->NamePtr,USER,5,1);
//}


//void os_obj_init(void)
//{
//	OS_ERR err;
//	OSSemCreate ((OS_SEM*)      &wave_sem,
//							 (CPU_CHAR*)    "WAVE_SEM",
//							 (OS_SEM_CTR)   0,
//							 (OS_ERR*)      &err);
//}

//int main(void)
//{
//	OS_ERR err;

//	OSInit(&err);

//	OSTaskCreate(  (OS_TCB     *)&app_start_tcb,                /* Create the start task                                */
//                 (CPU_CHAR   *)"APP_START",
//                 (OS_TASK_PTR ) app_start,
//                 (void       *) 0,
//                 (OS_PRIO     ) app_start_prio,
//                 (CPU_STK    *)&app_start_stk[0],
//                 (CPU_STK_SIZE) app_start_stk_size / 10,
//                 (CPU_STK_SIZE) app_start_stk_size,
//                 (OS_MSG_QTY  ) 5u,
//                 (OS_TICK     ) 0u,
//                 (void       *) 0,
//                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
//                 (OS_ERR     *)&err);
//  os_obj_init();
//	OSStart(&err);

//}


//static  void  app_start (void *p_arg)
//{
//    CPU_INT32U  cpu_clk_freq;
//    CPU_INT32U  cnts;
//    OS_ERR      err;


//   (void)p_arg;
//	
//    CPU_Init();
//    BSP_Init();                                                 /* Initialize BSP functions                             */

//    cpu_clk_freq = BSP_CPU_ClkFreq();                           /* Determine SysTick reference freq.                    */
//    cnts = cpu_clk_freq / (CPU_INT32U)OSCfg_TickRate_Hz;        /* Determine nbr SysTick increments                     */
//    OS_CPU_SysTickInit(cnts);                                   /* Init uC/OS periodic time src (SysTick).              */

//    Mem_Init();                                                 /* Initialize Memory Management Module                  */
//    CPU_SR_ALLOC();
//#if OS_CFG_STAT_TASK_EN > 0u
//    OSStatTaskCPUUsageInit(&err);                               /* Compute CPU capacity with no task running            */
//#endif

//#ifdef CPU_CFG_INT_DIS_MEAS_EN
//    CPU_IntDisMeasMaxCurReset();
//#endif

//    OS_CRITICAL_ENTER();
//		app_creat_task();
//    OS_CRITICAL_EXIT();
//		
//		
//		
//		OSTaskDel((OS_TCB *)0,&err);
//}


//static void app_creat_task(void)
//{
//	OS_ERR err;
//	OSTaskCreate ((OS_TCB *)        &app_lcd_show_tcb,
//								(CPU_CHAR *)      "app_lcd_show_tcb",
//								(OS_TASK_PTR)     app_lcd_show,
//								(void *)          0,
//								(OS_PRIO)         app_lcd_show_prio,
//								(CPU_STK*)        &app_lcd_show_stk,
//								(CPU_STK_SIZE)    app_lcd_show_stk_size/10,
//								(CPU_STK_SIZE)    app_lcd_show_stk_size,
//								(OS_MSG_QTY )     5u,
//								(OS_TICK)         0u,
//								(void *)          0,
//								(OS_OPT )         (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
//								(OS_ERR *)        &err);		
//								
//	OSTaskCreate ((OS_TCB *)        &app_data_get_tcb,
//								(CPU_CHAR *)      "app_data_get_tcb",
//								(OS_TASK_PTR)     app_data_get,
//								(void *)          0,
//								(OS_PRIO)         app_data_get_prio,
//								(CPU_STK*)        &app_data_get_stk,
//								(CPU_STK_SIZE)    app_data_get_stk_size/10,
//								(CPU_STK_SIZE)    app_data_get_stk_size,
//								(OS_MSG_QTY )     5u,
//								(OS_TICK)         0u,
//								(void *)          0,
//								(OS_OPT )         (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
//								(OS_ERR *)        &err);	

//	OSTaskCreate ((OS_TCB *)        &app_gt5x_tcb,
//								(CPU_CHAR *)      "app_gt5x_tcb",
//								(OS_TASK_PTR)     app_gt5x_get,
//								(void *)          0,
//								(OS_PRIO)         app_gt5x_prio,
//								(CPU_STK*)        &app_gt5x_stk,
//								(CPU_STK_SIZE)    app_gt5x_stk_size/10,
//								(CPU_STK_SIZE)    app_gt5x_stk_size,
//								(OS_MSG_QTY )     5u,
//								(OS_TICK)         0u,
//								(void *)          0,
//								(OS_OPT )         (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
//								(OS_ERR *)        &err);									

//	OSTaskCreate ((OS_TCB *)        &app_task_mag_tcb,
//								(CPU_CHAR *)      "app_task_mag_tcb",
//								(OS_TASK_PTR)     app_task_mag,
//								(void *)          0,
//								(OS_PRIO)         app_task_mag_prio,
//								(CPU_STK*)        &app_task_mag_stk,
//								(CPU_STK_SIZE)    app_task_mag_stk_size/10,
//								(CPU_STK_SIZE)    app_task_mag_stk_size,
//								(OS_MSG_QTY )     5u,
//								(OS_TICK)         0u,
//								(void *)          0,
//								(OS_OPT )         (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
//								(OS_ERR *)        &err);	


//	OSTaskCreate ((OS_TCB *)        &app_tmr_tcb,
//								(CPU_CHAR *)      "app_tmr_tcb",
//								(OS_TASK_PTR)     app_tmr_mag,
//								(void *)          0,
//								(OS_PRIO)         app_tmr_prio,
//								(CPU_STK*)        &app_tmr_stk,
//								(CPU_STK_SIZE)    app_tmr_stk_size/10,
//								(CPU_STK_SIZE)    app_tmr_stk_size,
//								(OS_MSG_QTY )     5u,
//								(OS_TICK)         0u,
//								(void *)          0,
//								(OS_OPT )         (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
//								(OS_ERR *)        &err);									
//								
//}

//static void app_lcd_show(void *p_arg)
//{
//	CPU_SR_ALLOC();
//	OS_ERR err;
//	p_arg = p_arg;
//	while(1)
//	{
//	
//		OSTaskSemPend(0, OS_OPT_PEND_BLOCKING,0,&err);
//		OS_CRITICAL_ENTER();
//		LCD_Draw_Wave();
//		OS_CRITICAL_EXIT();
//		
//		
//		if(data_get_pause == 0)
//		{
//			OSTaskSemPost(&app_data_get_tcb,OS_OPT_POST_NONE,&err);
//		}
//		else
//		{
//			OSTaskSemPost(&app_gt5x_tcb,OS_OPT_POST_NONE,&err);
//		}
//		
//		
//		OSTimeDly(50,OS_OPT_TIME_DLY,&err);
//	}

//}

//static void app_data_get(void *p_arg)
//{
//	unsigned char state = 0;
//	unsigned int a = 0;
//	OS_ERR err;
//	p_arg = p_arg;
//	while(1)
//	{
//		state = get_one_data((float)50*sin(a*10*3.14/180) );//ADC_ConvertedValue);
//		a++;
//		if(state == 1)
//		{
//			OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);
//			OSTaskSemPend(0,OS_OPT_PEND_BLOCKING,0,&err);
//		}
//		OSTimeDly(1,OS_OPT_TIME_DLY,&err);
//	}
//}

//static void app_gt5x_get(void *p_arg)
//{
//	unsigned char state = 0;
//	unsigned char state1 = 0;
//	OS_ERR err;
//	p_arg = p_arg;
//	CPU_SR_ALLOC();
//	while(1)
//	{
//		OS_CRITICAL_ENTER();
//    state = GTP_TouchProcess(); 
//		OS_CRITICAL_EXIT();
//		
//		if(state==0 && state1 == 1 && data_get_pause == 1)
//		{
//			OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);
//		}
//		
//		if(scroll_flg == 1 && data_get_pause == 1)
//		{
//			OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);
//		}
//			
//		state1 = state;	
//		
//		OSTimeDly(50,OS_OPT_TIME_DLY,&err);
//	}
//}

//static void app_task_mag(void *p_arg)
//{
//	unsigned char state = 0;
//	unsigned char state1 = 0;
//	OS_ERR err;
//	p_arg = p_arg;
//	while(1)
//	{
//		if(data_get_pause == 1 && state == 0)
//		{
//			OSTaskSuspend(&app_data_get_tcb,&err);
//			state = 1;
//	  }
//		else if(data_get_pause == 0 && state == 1)
//		{
//			state = 0;
//			OSTaskResume(&app_data_get_tcb,&err);
//		}

//		OSTimeDly(100,OS_OPT_TIME_DLY,&err);
//	}
//}

//static void app_tmr_mag(void *p_arg)
//{
//		OS_ERR err;
//	p_arg = p_arg;
//	
//	OSTmrCreate ((OS_TMR*)               &os_tmr1,
//						 (CPU_CHAR*)             "TMR1",
//						 (OS_TICK)               10,
//						 (OS_TICK)               10,
//						 (OS_OPT)                OS_OPT_TMR_PERIODIC,
//						 (OS_TMR_CALLBACK_PTR)   app_tmr1_cb,
//						 (void*)                 0,
//						 (OS_ERR*)               &err);
//	
//	OSTmrStart(&os_tmr1,&err);
//	while(1)
//	{
//		OSTimeDly(5000,OS_OPT_TIME_DLY,&err);
//	}
//}

//void app_tmr1_cb(OS_TMR *tmr,void *p_arg)
//{
//	  static unsigned char state1 = 0;
//		get_all_tcb();
//		os_chk_stk(&tcb_table[state1++]);
//		if(state1 >4)
//		{
//			set_cmd("os_USAGE:  ",OSStatTaskCPUUsage/100,5,1);
//			state1 = 0;
//		}
//		show_cmd_table();
//	bsp_led_chg();
//}
