#include "3dplay.h"
#include "3d.h"     
#include "bsp_ili9806g_lcd.h"
//////////////////////////////////////////////////////////////////////////////////	 


//APP-3D ����	   


//�޸�����:2012/10/3
//�汾��V1.0

_t3d_obj* t3d_obj;
  
//��������ı߿�
//t3dx:3D��
//color:������ɫ
void t3dplay_draw_cube_rim(_t3d_obj* t3dx,u16 color)
{
	LCD_SetColors(color ,0xffff - color);
  ILI9806G_DrawLine(t3dx->p2dbuf[0].x,t3dx->p2dbuf[0].y,t3dx->p2dbuf[1].x,t3dx->p2dbuf[1].y);//����
  ILI9806G_DrawLine(t3dx->p2dbuf[0].x,t3dx->p2dbuf[0].y,t3dx->p2dbuf[3].x,t3dx->p2dbuf[3].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[0].x,t3dx->p2dbuf[0].y,t3dx->p2dbuf[4].x,t3dx->p2dbuf[4].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[2].x,t3dx->p2dbuf[2].y,t3dx->p2dbuf[1].x,t3dx->p2dbuf[1].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[2].x,t3dx->p2dbuf[2].y,t3dx->p2dbuf[3].x,t3dx->p2dbuf[3].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[2].x,t3dx->p2dbuf[2].y,t3dx->p2dbuf[6].x,t3dx->p2dbuf[6].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[5].x,t3dx->p2dbuf[5].y,t3dx->p2dbuf[1].x,t3dx->p2dbuf[1].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[5].x,t3dx->p2dbuf[5].y,t3dx->p2dbuf[6].x,t3dx->p2dbuf[6].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[5].x,t3dx->p2dbuf[5].y,t3dx->p2dbuf[4].x,t3dx->p2dbuf[4].y);//����
  ILI9806G_DrawLine(t3dx->p2dbuf[7].x,t3dx->p2dbuf[7].y,t3dx->p2dbuf[3].x,t3dx->p2dbuf[3].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[7].x,t3dx->p2dbuf[7].y,t3dx->p2dbuf[6].x,t3dx->p2dbuf[6].y);//����
 	ILI9806G_DrawLine(t3dx->p2dbuf[7].x,t3dx->p2dbuf[7].y,t3dx->p2dbuf[4].x,t3dx->p2dbuf[4].y);//����
}  
//��һ��3d������
//t3dx:3D��
//color:������ɫ.
//bkcolor:������ɫ.
void t3dplay_draw_cube(_t3d_obj* t3dx,u16 color,u16 bkcolor)
{	 		 
	t3dplay_draw_cube_rim(t3dx,bkcolor);
	t3d_show_obj(10,80,220,220,t3dx,bkcolor);	//����ʾ��.
	t3dplay_draw_cube_rim(t3dx,color);
}	  


void t3d_init(void)
{
	t3d_obj=t3d_creat(550,270,50,8);
	if(t3d_obj)
	{
	  t3d_draw_point(t3d_obj,0,-25,-25,-25,RED);	//�����������8��������
		t3d_draw_point(t3d_obj,1,25,-25,-25,RED);
		t3d_draw_point(t3d_obj,2,25,25,-25,RED);
		t3d_draw_point(t3d_obj,3,-25,25,-25,RED);
		t3d_draw_point(t3d_obj,4,-25,-25,25,RED);
		t3d_draw_point(t3d_obj,5,25,-25,25,RED);
		t3d_draw_point(t3d_obj,6,25,25,25,RED);
		t3d_draw_point(t3d_obj,7,-25,25,25,RED);
		t3d_obj->pixsize=8;
 	}
	
}


void t3d_set_angle(short x,short y,short z)
{
		t3d_obj->ang.x = x;
		t3d_obj->ang.y = y;
	  t3d_obj->ang.z = z;
}

void t3d_play(void)
{
	
	t3dplay_draw_cube(t3d_obj,RED,BLACK);
	LCD_SetColors(0xffff,0x0000);
}




























