#ifndef __3DPLAY_H
#define __3DPLAY_H
#include "stm32f4xx.h"
//////////////////////////////////////////////////////////////////////////////////	 


//APP-3D ����	   


//�޸�����:2012/10/3
//�汾��V1.0


//All rights reserved									  
////////////////////////////////////////////////////////////////////////////////// 	   

void t3d_init(void);
void t3d_set_angle(short x,short y,short z);
void t3d_play(void);
#endif












