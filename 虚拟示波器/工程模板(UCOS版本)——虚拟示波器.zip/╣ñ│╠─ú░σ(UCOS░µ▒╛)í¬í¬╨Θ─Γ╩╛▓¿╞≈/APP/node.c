#include "node.h"
#include "includes.h"
#include "bsp_usart.h"
#include "stdio.h"
__align(32) uint8_t node_mem[500][8] __attribute__((at(0X6C000000+0x4e40)));

typedef struct Node
{
	float data;
	struct Node *next;
}NODE ,*LinkList;

NODE *node;

NODE *node_F;

NODE *node_E;
static OS_MEM mem_node;

void NODE_MEM_Init(void)
{
	OS_ERR err;
	OSMemCreate ((OS_MEM*)       &mem_node,
							 (CPU_CHAR*)     "mem_node",
							 (void*)         node_mem,
							 (OS_MEM_QTY)    500,
							 (OS_MEM_SIZE)   8,
							 (OS_ERR*)       &err);
}

unsigned char Creat_LinkList(LinkList *L)
{
	OS_ERR err;
	*L = (LinkList)OSMemGet(&mem_node,&err);
	
	if(err != CPU_ERR_NONE)
	{
		return 0;
	}
	(*L)->next = 0;
}

void Creat_Node(LinkList *L)
{
	OS_ERR err;
	unsigned short i = 0;
	NODE *n;
	for(i=0;i<400;i++)  
    {  
        n = (LinkList)OSMemGet(&mem_node,&err);
			  if(i == 0)
				{
					node_E = n;
				}
        n->data = i;  
        n->next = (*L)->next;  
        (*L)->next = n; 
		}
		node_F = (*L)->next;
}

void Print_Node(void)
{
	unsigned short i = 0;
	NODE *n_tp;
	n_tp = node->next;
	for(i=0;i<400;i++)
	{
		 printf("%f \r\n",(n_tp->data));
	   n_tp = n_tp->next;
		
	}
	
}

void Get_One_Data(float data)
{
	OS_ERR err;
	NODE *n_tp;
	n_tp = node_F;
	node->next = n_tp->next;
	node_F = node->next;
	OSMemPut(&mem_node,n_tp,&err);
	n_tp = (LinkList)OSMemGet(&mem_node,&err);
	n_tp->data = data;
	node_E->next = n_tp;
	node_E = n_tp;
}

void Exchange_Data(float *p_arg)
{
	unsigned short i = 0;
	NODE *n_tp;
	n_tp = node->next;
	for(i=0;i<400;i++)
	{
		 p_arg[i] = n_tp->data;
	   n_tp = n_tp->next;
		
	}
}

void NODE_Init(void)
{
	NODE_MEM_Init();
	Creat_LinkList(&node);
	Creat_Node(&node);
	//Print_Node();
}




