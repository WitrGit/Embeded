#include "mpu_imu.h"
#include "math.h"
#include "bsp_mpu6050.h"

#define PI 3.1415926

#define Kalman_Filter 1

Angle angle_value;

#ifdef Quaternion 


#define Kp 100.0f                       
#define Ki 0.02f                
#define halfT 0.001f              


float q0 = 1, q1 = 0, q2 = 0, q3 = 0;          // ��Ԫ��Ԫ�� 
float exInt = 0, eyInt = 0, ezInt = 0;        // ��������С������� 

float Yaw,Pitch,Roll;  //ƫ���ǡ������ǡ���ת��

void IMUupdate(float gx, float gy, float gz, float ax, float ay, float az)  
{  
	float norm;
	float vx, vy, vz;
	float ex, ey, ez;

	float q0q0 = q0*q0;
	float q0q1 = q0*q1;
	float q0q2 = q0*q2;
	float q1q1 = q1*q1;
	float q1q3 = q1*q3;
	float q2q2 = q2*q2;
	float q2q3 = q2*q3;
	float q3q3 = q3*q3;
	if(ax*ay*az==0)
	return;

	norm = sqrt(ax*ax + ay*ay + az*az); 
	ax = ax / norm; 
	ay = ay / norm; 
	az = az / norm;  


	vx = 2*(q1q3 - q0q2); 
	vy = 2*(q0q1 + q2q3); 
	vz = q0q0 - q1q1 - q2q2 + q3q3 ;


	ex = ay*vz - az*vy ;
	ey = az*vx - ax*vz ;
	ez = ax*vy - ay*vx ;

	exInt = exInt + ex * Ki;
	eyInt = eyInt + ey * Ki;
	ezInt = ezInt + ez * Ki;

	gx = gx + Kp*ex + exInt;
	gy = gy + Kp*ey + eyInt;
	gz = gz + Kp*ez + ezInt;

	q0 = q0 + (-q1*gx - q2*gy - q3*gz)*halfT;
	q1 = q1 + (q0*gx + q2*gz - q3*gy)*halfT;
	q2 = q2 + (q0*gy - q1*gz + q3*gx)*halfT;
	q3 = q3 + (q0*gz + q1*gy - q2*gx)*halfT;


	Roll= -asin(-2*q1q3 + 2*q0q2)*57.30f;
	Pitch=atan2(2*q2q3 + 2*q0q1, -2*q1q1-2*q2q2 + 1)*57.30f; 
	Yaw=-atan2(2*q2q3 + 2*q0q1, -2*q1q1-2*q2q2 + 1)*57.30f; 
} 
#endif



#ifdef Kalman_Filter


           
float aax=0, aay=0,aaz=0, agx=0, agy=0, agz=0;      
long axo = 0, ayo = 0, azo = 0;          
long gxo = 0, gyo = 0, gzo = 0;             
  
float pi = 3.1415926;  
float AcceRatio = 16384.0;                 
float GyroRatio = 131.0;  
float dt = 0.001; 
  
unsigned char n_sample = 8;                     
float aaxs[8] = {0}, aays[8] = {0}, aazs[8] = {0};        
long aax_sum, aay_sum,aaz_sum;                     
  
float a_x[10]={0}, a_y[10]={0},a_z[10]={0} ,g_x[10]={0} ,g_y[10]={0},g_z[10]={0}; 
float Px=1, Rx, Kx, Sx, Vx, Qx;              
float Py=1, Ry, Ky, Sy, Vy, Qy;             
float Pz=1, Rz, Kz, Sz, Vz, Qz;  



void Kalman1_Filter(short ax,short ay,short az,short gx,short gy,short gz) 
{  
	  int i = 0;
	
	
    float accx = ax / AcceRatio;              
    float accy = ay / AcceRatio;              
    float accz = az / AcceRatio;   


    aax = atan(accy / accz) * (-180) / pi;    
    aay = atan(accx / accz) * 180 / pi;        
    aaz = atan(accz / accy) * 180 / pi;       
	
	  aax_sum = 0;                             
    aay_sum = 0;  
    aaz_sum = 0; 

		for( i=1;i<n_sample;i++)  
    {  
        aaxs[i-1] = aaxs[i];  
        aax_sum += aaxs[i] * i;  
        aays[i-1] = aays[i];  
        aay_sum += aays[i] * i;  
        aazs[i-1] = aazs[i];  
        aaz_sum += aazs[i] * i;  
      
    }  	

	  aaxs[n_sample-1] = aax;  
    aax_sum += aax * n_sample;  
    aax = (aax_sum / (11*n_sample/2.0)) * 9 / 7.0; 
    aays[n_sample-1] = aay;                      
    aay_sum += aay * n_sample;                     
    aay = (aay_sum / (11*n_sample/2.0)) * 9 / 7.0;  
    aazs[n_sample-1] = aaz;   
    aaz_sum += aaz * n_sample;  
    aaz = (aaz_sum / (11*n_sample/2.0)) * 9 / 7.0; 


    float gyrox = - (gx-gxo) / GyroRatio * dt;  
    float gyroy = - (gy-gyo) / GyroRatio * dt;  
    float gyroz = - (gz-gzo) / GyroRatio * dt;  
    agx += gyrox;                              
    agy += gyroy;                            
    agz += gyroz;  
      
    /* kalman start */  
    Sx = 0; Rx = 0;  
    Sy = 0; Ry = 0;  
    Sz = 0; Rz = 0;  


    for( i=1;i<10;i++)  
    {                   
        a_x[i-1] = a_x[i];                       
        Sx += a_x[i];  
        a_y[i-1] = a_y[i];  
        Sy += a_y[i];  
        a_z[i-1] = a_z[i];  
        Sz += a_z[i];  
      
    }
		
		 a_x[9] = aax;  
    Sx += aax;  
    Sx /= 10;                                
    a_y[9] = aay;  
    Sy += aay;  
    Sy /= 10;                                  
    a_z[9] = aaz;  
    Sz += aaz;  
    Sz /= 10;  
		
		
		for(int i=0;i<10;i++)  
    {  
        Rx += sqrt(a_x[i] - Sx);  
        Ry += sqrt(a_y[i] - Sy);  
        Rz += sqrt(a_z[i] - Sz);  
      
    }  
      
    Rx = Rx / 9;                              //????  
    Ry = Ry / 9;                          
    Rz = Rz / 9;  
		
		 Px = Px + 0.0025;                         // 0.0025??????...  
    Kx = Px / (Px + Rx);                      //???????  
    agx = agx + Kx * (aax - agx);             //??????????????  
    Px = (1 - Kx) * Px;                       //??p?  
  
    Py = Py + 0.0025;  
    Ky = Py / (Py + Ry);  
    agy = agy + Ky * (aay - agy);   
    Py = (1 - Ky) * Py;  
    
    Pz = Pz + 0.0025;  
    Kz = Pz / (Pz + Rz);  
    agz = agz + Kz * (aaz - agz);   
    Pz = (1 - Kz) * Pz;  
	
	
} 
#endif



void get_angle(void)
{
#ifdef Quaternion 

	IMUupdate(mpu6050_data.ax,
	          mpu6050_data.ay,
	          mpu6050_data.az,
	          mpu6050_data.gx,
	          mpu6050_data.gy,
	          mpu6050_data.gz);
	angle_value.Pitch = Pitch;
	angle_value.Roll = Roll;
	angle_value.Yaw = Yaw;

#endif	
	
	
#ifdef Kalman_Filter 

	Kalman1_Filter( mpu6050_data.ax,
									mpu6050_data.ay,
									mpu6050_data.az,
									mpu6050_data.gx,
									mpu6050_data.gy,
									mpu6050_data.gz);
									
	angle_value.Pitch = agx;
	angle_value.Roll = agy;
	angle_value.Yaw = agz;


#endif		
	
	
}
