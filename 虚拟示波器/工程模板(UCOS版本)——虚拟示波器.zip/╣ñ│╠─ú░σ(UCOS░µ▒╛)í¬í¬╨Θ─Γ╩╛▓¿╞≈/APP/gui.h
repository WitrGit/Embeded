#ifndef __GUI_H
#define __GUI_H

typedef struct
{
  unsigned short p_x;
	unsigned short p_y;
	unsigned short p_w;
	unsigned short p_h;
	unsigned char *name;
}GUI_BUTTON;


typedef struct
{
  unsigned short p_x;
	unsigned short p_y;
	unsigned char state;
	unsigned char *name;
}GUI_CHECKBOX;



unsigned char GUI_Get_Checkbox_State(unsigned char num);
void GUI_Draw_Control(void);
void GUI_Draw_Button_Text(unsigned char i,unsigned char *name);

unsigned char GUI_Click_Server( unsigned short s_x,
																unsigned short s_y)	;

#endif
