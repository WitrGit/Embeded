#ifndef __MPU_IMU_H
#define __MPU_IMU_H


typedef struct ANGLE
{
	float Pitch;
	float Roll;
	float Yaw;
}Angle;

extern Angle angle_value;

void get_angle(void);
#endif



