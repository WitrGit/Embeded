#ifndef __WAVE_H
#define __WAVE_H


extern unsigned short show_num_size ;
extern unsigned short show_offset ;
extern unsigned short show_offset_max ;
extern short show_num_max ;
extern short show_num_min ;

unsigned short wave_change_x_offset(unsigned char st,unsigned short oset);
unsigned short wave_change_show_num_size(unsigned char st);
unsigned short wave_change_max_offset(unsigned char st);
void LCD_Draw_Wave(void);
unsigned short get_show_offset_max(void);
float Wave_Get_Data(void);
void Draw_X_OFFSET(void);
unsigned char get_one_data(float value);
#endif
