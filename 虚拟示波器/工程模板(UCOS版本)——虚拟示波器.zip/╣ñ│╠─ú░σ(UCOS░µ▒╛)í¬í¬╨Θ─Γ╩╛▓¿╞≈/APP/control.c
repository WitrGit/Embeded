#include "control.h"

#include "bsp_ili9806g_lcd.h"

#include "wave.h"

void Button_Down_Serve(unsigned char id);
void Show_Button_Num(void);

const unsigned short size_table[7] = {10,20,40,80,100,200,400};

unsigned char data_get_pause = 0;

unsigned char sns_button_click_num = 6;
unsigned char offset_button_click_num = 0;
unsigned char click_id = 0;
#define ABS_ct(x)  ( (x)>0?(x):-(x) )
button_point bp[5];





void Draw_Button(button_point bp, char*name)
{
	LCD_SetColors(WHITE,BLACK);
	ILI9806G_DrawRectangle(bp.point_x1,bp.ponit_y1,ABS_ct(bp.point_x1-bp.point_x2),ABS_ct(bp.ponit_y1-bp.ponit_y2),1);
	LCD_SetColors(BLACK,WHITE);
	ILI9806G_DispString_EN(bp.point_x1+ABS_ct(bp.point_x1-bp.point_x2)/2-4,bp.ponit_y1+ABS_ct(bp.ponit_y1-bp.ponit_y2)/3,name);
	LCD_SetColors(WHITE,BLACK);
}

void Draw_All_Button(void)
{
	
	bp[0].id = 0;
	bp[0].point_x1 = 600;
	bp[0].ponit_y1 = 330;
	bp[0].point_x2 = 700;
	bp[0].ponit_y2 = 390;
	Draw_Button(bp[0],"+");
	
	bp[1].id = 1;
	bp[1].point_x1 = 750;
	bp[1].ponit_y1 = 330;
	bp[1].point_x2 = 850;
	bp[1].ponit_y2 = 390;
	Draw_Button(bp[1],"-");
//	
//	
  bp[2].id = 2;
	bp[2].point_x1 = 600;
	bp[2].ponit_y1 = 410;
	bp[2].point_x2 = 700;
	bp[2].ponit_y2 = 470;
	Draw_Button(bp[2],"+");
	
	
	bp[3].id = 3;
	bp[3].point_x1 = 750;
	bp[3].ponit_y1 = 410;
	bp[3].point_x2 = 850;
	bp[3].ponit_y2 = 470;
	Draw_Button(bp[3],"-");
	
	bp[4].id = 4;
	bp[4].point_x1 = 750;
	bp[4].ponit_y1 = 220;
	bp[4].point_x2 = 850;
	bp[4].ponit_y2 = 300;
	Draw_Button(bp[4],"pause");
}

void Control_Scroll(unsigned short x1,unsigned short y1,unsigned short x2,unsigned short y2)
{
	unsigned short temp = 0;
	if(x1>50 && y1<200)
	{
		ILI9806G_Draw_Int(500,250,x1,3);
		
		ILI9806G_Draw_Int(540,250,y1,3);
		
		ILI9806G_Draw_Int(500,280,x2,3);
		
		ILI9806G_Draw_Int(540,280,y2,3);
			
		ILI9806G_Draw_Int(500,310,ABS_ct(x2-x1)/10,3);
		temp = ABS_ct(x2-x1)/50;
		if(x2<x1)
		{
			if(show_offset<show_offset_max)
			{
				show_offset +=temp+1;
			}
			else
			{
				show_offset = show_offset_max;
			}
		}
		else
		{
			if(show_offset>temp)
			{
				show_offset -=temp;
			}
			else
			{
				show_offset = 0;
			}				
		}

	}
	Show_Button_Num();
	
	
}
void Button_Down(unsigned short x1,unsigned short y1)
{
	unsigned char i = 0;
	click_id = 0;
	
	
	
	for(i=0;i<5;i++)
	{
		if(x1>bp[i].point_x1&& x1<bp[i].point_x2 && y1<bp[i].ponit_y2 &&y1>bp[i].ponit_y1)
		{
			click_id = i+1;
			
			return ;
		}		
	}

	
}

void Show_Button_Num(void)
{
	
	ILI9806G_Draw_Int(600,220,show_num_size,4);
	ILI9806G_Draw_Int(600,250,show_offset,4);
	if(data_get_pause == 0)
	{
		ILI9806G_DispString_EN(600,280,"running");
	}
	else
	{
		ILI9806G_DispString_EN(600,280,"pause  ");
	}
	
}

void Button_Up(void)
{
	Button_Down_Serve(click_id);
}

void Button_Down_Serve(unsigned char id)
{
	switch(id)
	{
		case 1:
		{
			if(sns_button_click_num<7)
			{
				
				show_num_size = size_table[sns_button_click_num];
				sns_button_click_num ++;
				
			}
			else if(sns_button_click_num == 7)
			{
				sns_button_click_num = 6;
			}
			
			
		}break;
		case 2:		
		{
			if(sns_button_click_num>0)
			{
				sns_button_click_num --;
				show_num_size = size_table[sns_button_click_num];

			}
       else if(sns_button_click_num == 0)
			 {
				 sns_button_click_num = 1;
			 }				 
		}break;
		case 3:
		{
			
			if(show_offset<get_show_offset_max())
			{
				show_offset +=10;

			}
			else
			{
				show_offset = get_show_offset_max();
			}

		}break;
		case 4:
		{
			
			if(show_offset>10 )
			{
				show_offset -=10;
		
			}
			else
			{
				show_offset = 0;
			}

		}break;
		case 5: data_get_pause = 1 - data_get_pause;break;
		
		
	}
	
	Show_Button_Num();
}
