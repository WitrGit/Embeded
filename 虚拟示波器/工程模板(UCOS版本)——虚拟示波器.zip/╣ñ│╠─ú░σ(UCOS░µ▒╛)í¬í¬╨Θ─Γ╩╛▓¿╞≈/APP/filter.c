#include "filter.h"


float KalmanFilter_Parameter[4]= { 0, 0, 0.0895,  2.3478 };//pre cov q r
float KalmanFilter(float ResrcData)
{
		float Kalman_K = 0;

		KalmanFilter_Parameter[1] = KalmanFilter_Parameter[1] + KalmanFilter_Parameter[2];
		Kalman_K = KalmanFilter_Parameter[1] / (KalmanFilter_Parameter[1] + KalmanFilter_Parameter[3]);
		KalmanFilter_Parameter[0] = KalmanFilter_Parameter[0] + Kalman_K * (ResrcData - KalmanFilter_Parameter[0]);
		KalmanFilter_Parameter[1] = (1 - Kalman_K) * KalmanFilter_Parameter[1];
		return KalmanFilter_Parameter[0]; 
}  