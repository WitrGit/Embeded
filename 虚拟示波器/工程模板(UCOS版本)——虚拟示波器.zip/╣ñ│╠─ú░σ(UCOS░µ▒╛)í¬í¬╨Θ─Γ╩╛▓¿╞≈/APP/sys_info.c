#include "sys_info.h"
#include "bsp_ili9806g_lcd.h"

#define DRAW_X  380
#define DRAW_Y  350
#define info_size  6


const unsigned char info_name[10][20] = 
{
	"state        :",
	"energy       :",
	"CPUUsage     :",
	"wave_time    :",
  "wave_x_offset:",
	"wave_y_offset:",
	"wave_max     :",
	"wave_min     :",
	"touch_sc_w   :",
	"touch_sc_h   :"
};

OS_INFO os_info[10];


void sys_info_creat(void)
{
	unsigned char i = 0;
	for(i=0;i<info_size;i++)
	{
		os_info[i].name =(unsigned char *)info_name[i];
		os_info[i].data = 0;
	}
  draw_sys_info();
}

void draw_sys_info(void)
{
	unsigned char i =0 ;
	
	for(i=0;i<info_size;i++)
	{
		LCD_SetColors(BLUE,0x0000);
		if(i == 2 || i == 3|| i == 5)
		{
			ILI9806G_Print_Warring(DRAW_X,DRAW_Y+i*20,(char*)os_info[i].name,os_info[i].data,5);
		}
		else
		{
			ILI9806G_Print_Warring(DRAW_X,DRAW_Y+i*20,(char*)os_info[i].name,os_info[i].data,3);
		}
		
		LCD_SetColors(0xffff,0x0000);
		ILI9806G_DrawLine(370,DRAW_Y+i*20+18,625,DRAW_Y+i*20+18);
	}
	
	

	
	
}





