#ifndef __SYS_INFO_H
#define __SYS_INFO_H


typedef struct
{
	unsigned char *name;
	short data;
	
}OS_INFO;
extern OS_INFO os_info[10];

void sys_info_creat(void);
void draw_sys_info(void);






#endif


