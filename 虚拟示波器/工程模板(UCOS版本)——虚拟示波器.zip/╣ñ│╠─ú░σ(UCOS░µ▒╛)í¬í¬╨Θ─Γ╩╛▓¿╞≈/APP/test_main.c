#include "includes.h"
#include "bsp_led.h"
#include "bsp_adc.h"
#include "bsp_usart.h"
#include "debug.h"
#include "filter.h"
#include "wave.h"
#include "gt5xx.h"
#include "control.h"
#include "gui.h"
#include "sys_info.h"
#include "node.h"
#include "bsp_mpu6050.h"
#include "mpu_imu.h"
#include "3dplay.h"
extern __IO uint16_t ADC_ConvertedValue;
float ADC_ConvertedValueLocal; 
/***************************************************/
unsigned char os_state = 0;
unsigned char data_chl = 0;
unsigned char data_filter = 0;
unsigned char data_usart = 0;
unsigned char mpu_data_sel = 0;
OS_TCB tcb_table[10];

__align(32) uint8_t mem2base[100][50*4] __attribute__((at(0X6C000000)));

/********************************��������***********************************/
static void app_start (void *p_arg);
static void app_creat_task(void);
static void app_get_data_task(void *p_arg);//��ȡ����
static void app_mplt_data_task(void *p_arg);//��������	
static void app_synthesis_data_task(void *p_arg);//�ۺ�����
static void app_lcd_show_task(void *p_arg);//LCD��ʾ
static void app_lcd_touch_task(void *p_arg);//��������
static void app_statistics_task(void *p_arg);//ͳ������	
static void app_osinfo_show_task(void *p_arg);//ϵͳ��Ϣ��ʾ����
static void app_usart_show_task(void *p_arg);//��������ʾ����
static void app_3d_show_task(void *p_arg);//3D��ʾ����
static void app_statistics_tmr_callback(OS_TMR *tmr,void *p_arg);//ͳ������ʱ���ص�
static void touch_click_server(unsigned char key_value);
static void touch_scroll_server(short *scroll_data);
/********************************��������***********************************/
/*****��ʼ����*******/

#define app_start_prio     3u
#define app_start_stk_size 128u
static  OS_TCB  app_start_tcb;
static  CPU_STK app_start_stk[app_start_stk_size];

/*****��ȡ��������*******/

#define app_get_data_prio     4u
#define app_get_data_stk_size 1280u
static  OS_TCB  app_get_data_tcb;
static  CPU_STK app_get_data_stk[app_get_data_stk_size];

/*****������������*******/


#define app_mplt_data_prio     5u
#define app_mplt_data_stk_size 128u
static  OS_TCB  app_mplt_data_tcb;
static  CPU_STK app_mplt_data_stk[app_mplt_data_stk_size];


/*****�ۺ���������*******/


#define app_synthesis_data_prio     6u
#define app_synthesis_data_stk_size 128u
static  OS_TCB  app_synthesis_data_tcb;
static  CPU_STK app_synthesis_data_stk[app_synthesis_data_stk_size];


/*****LCD��ʾ����*******/

#define app_lcd_show_prio     7u
#define app_lcd_show_stk_size 128u
static  OS_TCB  app_lcd_show_tcb;
static  CPU_STK app_lcd_show_stk[app_lcd_show_stk_size];


/*****������������*******/

#define app_lcd_touch_prio     8u
#define app_lcd_touch_stk_size 128u
static  OS_TCB  app_lcd_touch_tcb;
static  CPU_STK app_lcd_touch_stk[app_lcd_touch_stk_size];

/*****ͳ����������*******/
#define app_statistics_prio     9u
#define app_statistics_stk_size 128u
static  OS_TCB  app_statistics_tcb;
static  CPU_STK app_statistics_stk[app_statistics_stk_size];

/*****ϵͳ��Ϣ��ʾ����*******/
#define app_osinfo_show_prio     10u
#define app_osinfo_show_stk_size 128u
static  OS_TCB  app_osinfo_show_tcb;
static  CPU_STK app_osinfo_show_stk[app_osinfo_show_stk_size];

/*****��������ʾ����*******/
#define app_usart_show_prio     11u
#define app_usart_show_stk_size 128u
static  OS_TCB  app_usart_show_tcb;
static  CPU_STK app_usart_show_stk[app_usart_show_stk_size];

/*****3D��ʾ����*******/
#define app_3d_show_prio     12u
#define app_3d_show_stk_size 128u
static  OS_TCB  app_3d_show_tcb;
static  CPU_STK app_3d_show_stk[app_3d_show_stk_size];

/********************************�ڴ�����***********************************/
static OS_MEM mem_1;
/********************************��ʱ������***********************************/

static OS_TMR tmr_1; 
/********************************�ź�������***********************************/
static OS_MUTEX mutex;
static OS_MUTEX mutex_lcd;
/********************************��Ϣ��������***********************************/

static OS_Q queue1;
static OS_Q queue2;
static OS_Q queue3;
/********************************����ʵ��***********************************/

void get_all_tcb(void)
{
	tcb_table[0] = app_get_data_tcb;
	tcb_table[1] = app_mplt_data_tcb;
	tcb_table[2] = app_synthesis_data_tcb;
	tcb_table[3] = app_lcd_show_tcb;
	tcb_table[4] = app_lcd_touch_tcb;
	tcb_table[5] = app_statistics_tcb;
	tcb_table[6] = app_osinfo_show_tcb;
  tcb_table[7] = app_usart_show_tcb;
	tcb_table[8] = app_3d_show_tcb;
}

void os_chk_stk(OS_TCB *tcb)
{
	OS_ERR err;
	CPU_STK_SIZE FREE;
	CPU_STK_SIZE USER;
	OSTaskStkChk(tcb,&FREE,&USER,&err);
	set_cmd(tcb->NamePtr,USER,5,1);
}
void os_obj_init(void)
{
	OS_ERR err;
	OSQCreate ((OS_Q *)        &queue1,
						 (CPU_CHAR*)     "queue1",
						 (OS_MSG_QTY)    20,
						 (OS_ERR*)       &err);
	OSQCreate ((OS_Q *)        &queue2,
						 (CPU_CHAR*)     "queue2",
						 (OS_MSG_QTY)    20,
						 (OS_ERR*)       &err);
	OSQCreate ((OS_Q *)        &queue3,
					 (CPU_CHAR*)       "queue3",
					 (OS_MSG_QTY)      20,
					 (OS_ERR*)         &err);
	OSMutexCreate ((OS_MUTEX*)  &mutex,
								 (CPU_CHAR*)  "mutex",
								 (OS_ERR*)    &err);
	
	OSMutexCreate ((OS_MUTEX*)  &mutex_lcd,
								 (CPU_CHAR*)  "mutex",
								 (OS_ERR*)    &err);
		
	OSMemCreate ((OS_MEM*)       &mem_1,
							 (CPU_CHAR*)     "mem_1",
							 (void*)         mem2base,
							 (OS_MEM_QTY)    10,
							 (OS_MEM_SIZE)   4*50,
							 (OS_ERR*)       &err);
	NODE_Init();
}

int main(void)
{
	OS_ERR err;

	OSInit(&err);

	OSTaskCreate(  (OS_TCB     *)&app_start_tcb,                /* Create the start task                                */
                 (CPU_CHAR   *)"APP_START",
                 (OS_TASK_PTR ) app_start,
                 (void       *) 0,
                 (OS_PRIO     ) app_start_prio,
                 (CPU_STK    *)&app_start_stk[0],
                 (CPU_STK_SIZE) app_start_stk_size / 10,
                 (CPU_STK_SIZE) app_start_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
  os_obj_init();

	OSStart(&err);

}


static  void  app_start (void *p_arg)
{
    CPU_INT32U  cpu_clk_freq;
    CPU_INT32U  cnts;
    OS_ERR      err;


   (void)p_arg;
	
    CPU_Init();
    BSP_Init();                                                 /* Initialize BSP functions                             */

    cpu_clk_freq = BSP_CPU_ClkFreq();                           /* Determine SysTick reference freq.                    */
    cnts = cpu_clk_freq / (CPU_INT32U)OSCfg_TickRate_Hz;        /* Determine nbr SysTick increments                     */
    OS_CPU_SysTickInit(cnts);                                   /* Init uC/OS periodic time src (SysTick).              */

    Mem_Init();                                                 /* Initialize Memory Management Module                  */
    CPU_SR_ALLOC();
#if OS_CFG_STAT_TASK_EN > 0u
    OSStatTaskCPUUsageInit(&err);                               /* Compute CPU capacity with no task running            */
#endif

#ifdef CPU_CFG_INT_DIS_MEAS_EN
    CPU_IntDisMeasMaxCurReset();
#endif

    OS_CRITICAL_ENTER();
		app_creat_task();
    OS_CRITICAL_EXIT();
		
		
		
		OSTaskDel((OS_TCB *)0,&err);
}

static void app_creat_task(void)
{
	OS_ERR err;
/************************��ȡ����*************************************/
	OSTaskCreate(  (OS_TCB     *)&app_get_data_tcb,            
                 (CPU_CHAR   *)"get_data",
                 (OS_TASK_PTR ) app_get_data_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_get_data_prio,
                 (CPU_STK    *)&app_get_data_stk[0],
                 (CPU_STK_SIZE) app_get_data_stk_size / 10,
                 (CPU_STK_SIZE) app_get_data_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
/************************��������*************************************/							 
								 
  OSTaskCreate(  (OS_TCB     *)&app_mplt_data_tcb,               
                 (CPU_CHAR   *)"mplt_data",
                 (OS_TASK_PTR ) app_mplt_data_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_mplt_data_prio,
                 (CPU_STK    *)&app_mplt_data_stk[0],
                 (CPU_STK_SIZE) app_mplt_data_stk_size / 10,
                 (CPU_STK_SIZE) app_mplt_data_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
/************************�ۺ�����*************************************/												 
								 
	OSTaskCreate(  (OS_TCB     *)&app_synthesis_data_tcb,                
                 (CPU_CHAR   *)"synthesis_data",
                 (OS_TASK_PTR ) app_synthesis_data_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_synthesis_data_prio,
                 (CPU_STK    *)&app_synthesis_data_stk[0],
                 (CPU_STK_SIZE) app_synthesis_data_stk_size / 10,
                 (CPU_STK_SIZE) app_synthesis_data_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
/************************LCD��ʾ*************************************/									 
								 
	OSTaskCreate(  (OS_TCB     *)&app_lcd_show_tcb,               
                 (CPU_CHAR   *)"lcd_show",
                 (OS_TASK_PTR ) app_lcd_show_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_lcd_show_prio,
                 (CPU_STK    *)&app_lcd_show_stk[0],
                 (CPU_STK_SIZE) app_lcd_show_stk_size / 10,
                 (CPU_STK_SIZE) app_lcd_show_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
								 
/************************������������*************************************/										 
	OSTaskCreate(  (OS_TCB     *)&app_lcd_touch_tcb,               
                 (CPU_CHAR   *)"lcd_touch",
                 (OS_TASK_PTR ) app_lcd_touch_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_lcd_touch_prio,
                 (CPU_STK    *)&app_lcd_touch_stk[0],
                 (CPU_STK_SIZE) app_lcd_touch_stk_size / 10,
                 (CPU_STK_SIZE) app_lcd_touch_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
								 
								 
/************************ͳ����������*************************************/										 
	OSTaskCreate(  (OS_TCB     *)&app_statistics_tcb,                
                 (CPU_CHAR   *)"statistics",
                 (OS_TASK_PTR ) app_statistics_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_statistics_prio,
                 (CPU_STK    *)&app_statistics_stk[0],
                 (CPU_STK_SIZE) app_statistics_stk_size / 10,
                 (CPU_STK_SIZE) app_statistics_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);
/************************ϵͳ��Ϣ��ʾ����*************************************/										 
	OSTaskCreate(  (OS_TCB     *)&app_osinfo_show_tcb,                
                 (CPU_CHAR   *)"osinfo_show",
                 (OS_TASK_PTR ) app_osinfo_show_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_osinfo_show_prio,
                 (CPU_STK    *)&app_osinfo_show_stk[0],
                 (CPU_STK_SIZE) app_osinfo_show_stk_size / 10,
                 (CPU_STK_SIZE) app_osinfo_show_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);		
/************************��������ʾ����*************************************/										 
	OSTaskCreate(  (OS_TCB     *)&app_usart_show_tcb,                
                 (CPU_CHAR   *)"usart_show",
                 (OS_TASK_PTR ) app_usart_show_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_usart_show_prio,
                 (CPU_STK    *)&app_usart_show_stk[0],
                 (CPU_STK_SIZE) app_usart_show_stk_size / 10,
                 (CPU_STK_SIZE) app_usart_show_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);				

/***********************3D��ʾ����*************************************/										 
	OSTaskCreate(  (OS_TCB     *)&app_3d_show_tcb,                
                 (CPU_CHAR   *)"3d_show",
                 (OS_TASK_PTR ) app_3d_show_task,
                 (void       *) 0,
                 (OS_PRIO     ) app_3d_show_prio,
                 (CPU_STK    *)&app_3d_show_stk[0],
                 (CPU_STK_SIZE) app_3d_show_stk_size / 10,
                 (CPU_STK_SIZE) app_3d_show_stk_size,
                 (OS_MSG_QTY  ) 5u,
                 (OS_TICK     ) 0u,
                 (void       *) 0,
                 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 (OS_ERR     *)&err);									 
}

void delay_main(unsigned int tm)
{
	while(tm--);
}


static void app_get_data_task(void *p_arg)//��ȡ����
{
	OS_ERR err;
	float *data_tab;
	unsigned short tmp = 0;
	unsigned short sinc = 0;
	unsigned short size = 2;
	p_arg = p_arg;
	while(1)
	{
		  if(tmp == 0)
			{
				data_tab = OSMemGet(&mem_1,&err);
			}
			if(err == CPU_ERR_NONE)
			{
				for(tmp=0;tmp<size;tmp++)
				{
					switch(data_chl)
					{
						case 0:data_tab[tmp] = (float)(4095 - bsp_GetAdc(9));break;
						case 1:
						{
							mpu_get_all_data();
							get_angle();
							switch(mpu_data_sel)
							{
								case 0:
								{
									data_tab[tmp] = angle_value.Pitch;
									t3d_set_angle(0,data_tab[tmp]*10,0);
									
								}break;
								case 1:
								{
									data_tab[tmp] = angle_value.Roll;
								  t3d_set_angle(data_tab[tmp]*10,0,0);
								}break;
								case 2:data_tab[tmp] = angle_value.Yaw;break;	
							}
							
						}break;
						case 2:data_tab[tmp] = (float)50*sin(sinc*7*3.1415/180);break;
						
					}
					sinc++;
					//OSTimeDly(1,OS_OPT_TIME_DLY,&err);
				}
			}
				OSQPost ((OS_Q*)         &queue1,
								 (void*)          data_tab,
								 (OS_MSG_SIZE)   size,
								 (OS_OPT)        OS_OPT_POST_FIFO,
								 (OS_ERR*)       &err);
							 
				OSMutexPend ((OS_MUTEX*)  &mutex,
										 (OS_TICK)    0,
										 (OS_OPT)     OS_OPT_PEND_BLOCKING,
										 (CPU_TS*)    0,
										 (OS_ERR*)    &err);

		OSTimeDly(10,OS_OPT_TIME_DLY,&err);
}

}

static void app_mplt_data_task(void *p_arg)//��������
{
	OS_ERR err;
	unsigned short i = 0;
	CPU_SR_ALLOC();
	OS_MSG_SIZE msg_size;
	float *pMsg;
	
	p_arg = p_arg;

	while(1)
	{
		pMsg = OSQPend ((OS_Q         *)&queue1,                 
										(OS_TICK       )0,                     
										(OS_OPT        )OS_OPT_PEND_BLOCKING,   
										(OS_MSG_SIZE  *)&msg_size,              
										(CPU_TS       *)0,                      
										(OS_ERR       *)&err); 
		
		if(err ==  OS_ERR_NONE)
		{
			
			OS_CRITICAL_ENTER();   
			if(data_filter == 1)
			{
				for(i=0;i<msg_size;i++)
				{
					
					pMsg[i] = KalmanFilter(pMsg[i]);
					
				}
			}
			
			OS_CRITICAL_EXIT();
		}
		OSQPost ((OS_Q*)         &queue2,
						 (void*)          pMsg,
						 (OS_MSG_SIZE)    msg_size,
						 (OS_OPT)        OS_OPT_POST_FIFO,
						 (OS_ERR*)       &err);
			
		
		OSTimeDly(10,OS_OPT_TIME_DLY,&err);
	}
}

static void app_synthesis_data_task(void *p_arg)//�ۺ�����
{
	OS_ERR err;
	OS_MSG_SIZE msg_size;
	float *pMsg;
	float *tb;
	unsigned short i = 0;
	CPU_SR_ALLOC();

	p_arg = p_arg;
	while(1)
	{
			pMsg = OSQPend ((OS_Q         *)&queue2,                 
											(OS_TICK       )0,                     
											(OS_OPT        )OS_OPT_PEND_BLOCKING,   
											(OS_MSG_SIZE  *)&msg_size,              
											(CPU_TS       *)0,                      
											(OS_ERR       *)&err); 
		
		    if ( err == OS_ERR_NONE )                              //������ճɹ�
				{
					OS_CRITICAL_ENTER();                                 //�����ٽ��
					for(i=0;i<msg_size;i++)
					{
						Get_One_Data(pMsg[i]);						
					}
					get_one_data(0);
					if(data_usart == 1 )
					{
						tb = OSMemGet(&mem_1,&err);
						if(err == CPU_ERR_NONE)
						{
							for(i=0;i<msg_size;i++)
							{
								tb[i] = pMsg[i];
							}
							OSQPost ((OS_Q*)          &queue3,
											 (void*)          tb,
											 (OS_MSG_SIZE)    msg_size,
											 (OS_OPT)         OS_OPT_POST_FIFO,
											 (OS_ERR*)        &err);
							
						}
			
					}
					OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);
					OSMemPut(&mem_1,pMsg,&err);
					OS_CRITICAL_EXIT();
					
				}
			OSMutexPost( (OS_MUTEX*)  &mutex,
									 (OS_OPT)     OS_OPT_POST_NONE,
									 (OS_ERR*)    &err);
		OSTimeDly(10,OS_OPT_TIME_DLY,&err);
				
	}
}


static void app_lcd_show_task(void *p_arg)//LCD��ʾ
{
	OS_ERR err;
	CPU_SR_ALLOC();

	p_arg = p_arg;
	while(1)
	{

		OSTaskSemPend(0,OS_OPT_PEND_BLOCKING,0,&err);

		OS_CRITICAL_ENTER();
		
		LCD_Draw_Wave();				
		OS_CRITICAL_EXIT();
		OSTimeDly(50,OS_OPT_TIME_DLY,&err);
	}
}

static void app_lcd_touch_task(void *p_arg)//��������
{
	OS_ERR err;
	unsigned char state = 0;
	unsigned char state1 = 0;
	unsigned char key_value = 0;
	short sc_x_tmp = 0;
	short sc_y_tmp = 0;
	short gtp_data[7] = {0};
	CPU_SR_ALLOC();
	p_arg = p_arg;
	while(1)
	{
		
		OS_CRITICAL_ENTER();
    state = GTP_TouchProcess(); 
		
		if(state == 1)
		{
			
			gtp_data[0] = GTP_GET_INFO(&gtp_data[1],
			                           &gtp_data[2],
			                           &gtp_data[3],
			                           &gtp_data[4],
			                           &gtp_data[5],
			                           &gtp_data[6]);
			
			

				switch(gtp_data[0])
				{
					case 0:break;
					case 1:
					{
						if(sc_x_tmp != gtp_data[5] || sc_y_tmp != gtp_data[6])
						{
							touch_scroll_server(gtp_data);
							
						}
						
					}break;
					case 2:
					{
							if(gtp_data[0] != state1)
								{
									key_value = GUI_Click_Server(gtp_data[1],gtp_data[2]);
									touch_click_server(key_value);								
								}
							
					}break;
				}
			sc_x_tmp = gtp_data[5];
			sc_y_tmp = gtp_data[6];
			state1 = gtp_data[0];
		}
		else
		{
			state1 = 0;
		}
		
		OS_CRITICAL_EXIT();
		OSTimeDly(50,OS_OPT_TIME_DLY,&err);
	}
}


static void app_statistics_task(void *p_arg)//ͳ������
{
	OS_ERR err;
	p_arg = p_arg;
	
	OSTmrCreate ((OS_TMR*)               &tmr_1,
							 (CPU_CHAR*)             "tmr_1",
							 (OS_TICK)               0,
							 (OS_TICK)               10,
							 (OS_OPT)                OS_OPT_TMR_PERIODIC,
							 (OS_TMR_CALLBACK_PTR)   app_statistics_tmr_callback,
							 (void*)                 0,
							 (OS_ERR*)               &err);
							 
	OSTmrStart  ((OS_TMR*)               &tmr_1,
						   (OS_ERR*)               &err );
	while(1)
	{
		OSTimeDly(5000,OS_OPT_TIME_DLY,&err);
	}
}
static void app_statistics_tmr_callback(OS_TMR *tmr,void *p_arg)//ͳ������
{
	static unsigned char stk_ct = 0;
	
	bsp_led_chg();
	get_all_tcb();
	os_chk_stk(&tcb_table[stk_ct]); 
  stk_ct++;
  if(stk_ct>=9)
	{
		stk_ct = 0;
	}		
	show_cmd_table();
}
static void app_osinfo_show_task(void *p_arg)
{
	OS_ERR err;
	CPU_SR_ALLOC();
	p_arg = p_arg;
	while(1)
	{
		OS_CRITICAL_ENTER();
		
		os_info[1].data = (unsigned short)(bsp_GetAdc(8)*330/4096);
		
    os_info[2].data = OSStatTaskCPUUsage/100;	
		draw_sys_info();
		OS_CRITICAL_EXIT();
		OSTimeDly(200,OS_OPT_TIME_DLY,&err);
	}
}
static void app_usart_show_task(void *p_arg)
{
	OS_ERR err;
	unsigned short i = 0;
	OS_MSG_SIZE msg_size;
	float *pMsg;
	CPU_SR_ALLOC();
	p_arg = p_arg;
	while(1)
	{
		pMsg = OSQPend ((OS_Q         *)&queue3,                 
										(OS_TICK       )0,                     
										(OS_OPT        )OS_OPT_PEND_BLOCKING,   
										(OS_MSG_SIZE  *)&msg_size,              
										(CPU_TS       *)0,                      
										(OS_ERR       *)&err); 
		
		for(i=0;i<msg_size;i++)
		{	
			OS_CRITICAL_ENTER();

			usart_osc_send_data(pMsg[i],0,0,0);
			OS_CRITICAL_EXIT();
			
		}
		OSMemPut(&mem_1,pMsg,&err);
		OSTimeDly(50,OS_OPT_TIME_DLY,&err);
	}
}

static void app_3d_show_task(void *p_arg)
{
	OS_ERR err;
	CPU_SR_ALLOC();
	p_arg = p_arg;
	t3d_init();
	while(1)
	{
		OS_CRITICAL_ENTER();
		
		t3d_play();
		OS_CRITICAL_EXIT();
		OSTimeDly(200,OS_OPT_TIME_DLY,&err);
	}

}
static void touch_click_server(unsigned char key_value)
{
	OS_ERR err;

	//unsigned char os_state = 0;
	switch(key_value)
	{
		case 1:
		{
			if(os_state == 0)
			{
				os_state = 1;
				GUI_Draw_Button_Text(0,"running");
				OSTaskSuspend(&app_get_data_tcb,&err);
				OSTaskSemSet(&app_lcd_show_tcb,0,&err);
			}
			else
			{
				GUI_Draw_Button_Text(0,"pause");
				os_state = 0;
				OSTaskResume(&app_get_data_tcb,&err);
			}
			os_info[0].data = (1-os_state)*255;
			set_cmd("click_bu1",key_value,3,1);
			
		}break;
		case 2:
		{
			os_info[3].data = wave_change_show_num_size(1);
			OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);	
			set_cmd("click_bu2",key_value,3,1);
			
		}break;
		case 3:
		{
			os_info[3].data = wave_change_show_num_size(0);
			OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);	
			set_cmd("click_bu3",key_value,3,1);
		}break;
		case 4:
		{
			os_info[5].data =wave_change_max_offset(1);
			OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);	
			set_cmd("click_bu4",key_value,3,1);
		}break;
		case 5:
		{
			os_info[5].data =wave_change_max_offset(0);
			OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);	
			set_cmd("click_bu5",key_value,3,1);
		}break;
		case 6:
		{
			data_chl = 0;
			set_cmd("click_ck1",key_value,3,1);
		}break;
		case 7:
		{
			data_chl = 1;
			set_cmd("click_ck2",key_value,3,1);
		}break;
		case 8:
		{
			data_chl = 2;
			set_cmd("click_ck3",key_value,3,1);
		}break;
		case 9:
		{
			data_filter = GUI_Get_Checkbox_State(3);
			set_cmd("click_ck4",key_value,3,1);
		}break;
		case 10:
		{
			data_usart = GUI_Get_Checkbox_State(4);
			set_cmd("click_ck4",key_value,3,1);
		}break;
		case 11:
		{
			mpu_data_sel = 0;
			set_cmd("click_ck5",key_value,3,1);
		}break;
		case 12:
		{
			mpu_data_sel = 1;
			set_cmd("click_ck6",key_value,3,1);
		}break;
		case 13:
		{
			mpu_data_sel = 2;
			set_cmd("click_ck7",key_value,3,1);
		}break;
	}
	
}

static void touch_scroll_server(short *scroll_data)
{
	short tmp = 0;
	OS_ERR err;
  if(scroll_data[2]<200)
	{
		tmp = scroll_data[5];
		if(tmp>0)
		{
			os_info[4].data =wave_change_x_offset(1,tmp);
		}
		else
		{
			tmp = -tmp;
			os_info[4].data =wave_change_x_offset(0,tmp);
		}
		OSTaskSemPost(&app_lcd_show_tcb,OS_OPT_POST_NONE,&err);	
	}
	
}







