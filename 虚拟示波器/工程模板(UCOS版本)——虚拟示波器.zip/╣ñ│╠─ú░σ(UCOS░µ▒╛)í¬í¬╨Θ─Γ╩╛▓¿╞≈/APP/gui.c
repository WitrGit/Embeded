#include "gui.h"
#include "bsp_ili9806g_lcd.h"
#include "debug.h"
void GUI_Draw_Button(void);
void GUI_Draw_Checkbox(void);
void GUI_Draw_Line(void);

#define check_ct 8



const unsigned char button_name[5][10]=
{
	"pause","time+","time-","max+","max-"
};
const unsigned short button_posion[5][4]=
{
	{650,212,200,100},
	{650,320+20,80,50},
	{770,320+20,80,50},
	{650,400+20,80,50},
	{770,400+20,80,50}	
};	

unsigned char checkbox_state[check_ct] = {1,0,0,0,0,1,0,0};
const unsigned char checkbox_name[check_ct][10]=
{
	"ADC","6050","SINC","FILTER","USART","AGX","AGY","AGZ"
};
const unsigned short checkbox_posion[check_ct][2]=
{
	{265,340-5},
	{265,390-5},
	{265,440-5},
	{265,285-5},
	{265,245-5},
	
	{385,213},
	{385,253},
	{385,293},
};

GUI_BUTTON gui_button[5];
GUI_CHECKBOX  gui_checkbox[check_ct];

void GUI_Draw_Control(void)
{
  GUI_Draw_Button();
	GUI_Draw_Checkbox();
	GUI_Draw_Line();
}


void GUI_Draw_Button(void)
{
	unsigned short x =0 ;
	unsigned short y =0 ;
	unsigned char i = 0;
	for(i=0;i<5;i++)
	{
		gui_button[i].p_x = button_posion[i][0];
		gui_button[i].p_y = button_posion[i][1];
		gui_button[i].p_w = button_posion[i][2];
		gui_button[i].p_h = button_posion[i][3];
		gui_button[i].name =(unsigned char *)button_name[i];
		LCD_SetColors(0xffff,0x0000);
		ILI9806G_DrawRectangle( gui_button[i].p_x,
														gui_button[i].p_y,
														gui_button[i].p_w,
														gui_button[i].p_h,
		                        1);
		x = gui_button[i].p_x+gui_button[i].p_w/2-sizeof(gui_button[i].name)*4;
		y = gui_button[i].p_y+gui_button[i].p_h/2-8;
		LCD_SetColors(0x0000,0xffff);
		ILI9806G_DispString_EN(x,y,(char *)gui_button[i].name);
		LCD_SetColors(0xffff,0x0000);
	}
}

void GUI_Draw_Button_Text(unsigned char i,unsigned char *name)
{
	unsigned short x =0 ;
	unsigned short y =0 ;
	gui_button[i].name =(unsigned char *)name;
	LCD_SetColors(0xffff,0x0000);
	ILI9806G_DrawRectangle( gui_button[i].p_x,
													gui_button[i].p_y,
													gui_button[i].p_w,
													gui_button[i].p_h,
													1);	
	x = gui_button[i].p_x+gui_button[i].p_w/2-sizeof(gui_button[i].name)*4;
	y = gui_button[i].p_y+gui_button[i].p_h/2-8;
	LCD_SetColors(0x0000,0xffff);
	ILI9806G_DispString_EN(x,y,(char *)gui_button[i].name);
	LCD_SetColors(0xffff,0x0000);
}

void GUI_Draw_Checkbox(void)
{
	unsigned short x =0 ;
	unsigned short y =0 ;
	unsigned char i = 0;
	for(i=0;i<check_ct;i++)
	{
		gui_checkbox[i].p_x = checkbox_posion[i][0];
		gui_checkbox[i].p_y = checkbox_posion[i][1];
		gui_checkbox[i].name =(unsigned char *)checkbox_name[i];
		LCD_SetColors(0xffff,0X0000);
		gui_checkbox[i].state = checkbox_state[i];
		ILI9806G_Clear(gui_checkbox[i].p_x,gui_checkbox[i].p_y,32,32);
		ILI9806G_DrawRectangle( gui_checkbox[i].p_x,
														gui_checkbox[i].p_y,
														32,
														32,
		                        gui_checkbox[i].state);
		x = gui_checkbox[i].p_x+48;
		y = gui_checkbox[i].p_y+8;
		ILI9806G_DispString_EN(x,y,(char *)gui_checkbox[i].name);
	}
}

unsigned char GUI_Get_Checkbox_State(unsigned char num)
{
	return gui_checkbox[num].state;
}
void GUI_Draw_Line(void)
{
	
	ILI9806G_DrawLine(255,210,255,479);	
	ILI9806G_DrawLine(370,210,370,479);
	ILI9806G_DrawLine(625,210,625,479);
	
  	
	ILI9806G_DrawLine(255,330,625,330);
}

void GUI_Draw_SYS_INFO(void)
{
	
	
	
}


unsigned char GUI_Click_Server( unsigned short s_x,
																unsigned short s_y)																
{  
	unsigned char i =0;
	unsigned char j =0;
	unsigned short x_tmp = 0;
	unsigned short y_tmp = 0;
	if(s_x>625)
	{
		for(i=0;i<5;i++)
		{
			x_tmp = s_x-gui_button[i].p_x;
			y_tmp = s_y-gui_button[i].p_y;
			if(x_tmp>0 &&y_tmp>0)
			{
				if(x_tmp<gui_button[i].p_w && y_tmp<gui_button[i].p_h)
				{
					return i+1;
				}
			}
		}
	}
	else if(s_x>265 && s_x<420)
	{
		for(i=0;i<check_ct;i++)
		{
			x_tmp = s_x-gui_checkbox[i].p_x;
			y_tmp = s_y-gui_checkbox[i].p_y;
			if(x_tmp>0 &&y_tmp>0)
			{
				if(x_tmp<120 && y_tmp<60)
				{
					if(i<3)
					{
						for(j=0;j<3;j++)
						{
							if(i == j)
							{
								checkbox_state[j] = 1;
							}
							else
							{
								checkbox_state[j] = 0;
							}
						}					
					}
					else if(i>4)
					{
						for(j=5;j<8;j++)
						{
							if(i == j)
							{
								checkbox_state[j] = 1;
							}
							else
							{
								checkbox_state[j] = 0;
							}
						}							
					}
					else
					{
						checkbox_state[i] = 1 - checkbox_state[i];
					}

					
					GUI_Draw_Checkbox();
					return i+6;
				}
			}
		}
	}
	return 0;
}















