#ifndef __CONTROL_H
#define __CONTROL_H

extern unsigned char data_get_pause;


typedef struct
{
	unsigned int   id;
	unsigned short point_x1;
	unsigned short ponit_y1;
	unsigned short point_x2;
	unsigned short ponit_y2;
}button_point;

void Control_Scroll(unsigned short x1,unsigned short y1,unsigned short x2,unsigned short y2);
void Draw_All_Button(void);
void Button_Down(unsigned short x1,unsigned short y1);
void Button_Up(void);
#endif
